package com.study.poly.fashionista.view.dialog

interface IBmiResult {

    fun getSize(bmiSize : String)
}