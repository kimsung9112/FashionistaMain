package com.study.poly.fashionista.data

data class ClothesSaveModel(
    val email: String = "",
    val categoryPath: String = "",
    val titlePath: String = ""
)